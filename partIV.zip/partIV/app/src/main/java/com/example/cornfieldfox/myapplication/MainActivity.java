package com.example.cornfieldfox.myapplication;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity  {
    int [][]card;
    int quesNum = 0;
    int rightNum = 0;
    boolean bFlag = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button create = (Button) findViewById(R.id.Generatorbtn);
        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //initial
                quesNum = 0;
                rightNum = 0;
                RelativeLayout resL = (RelativeLayout) findViewById(R.id.RstLayout);
                resL.setVisibility(View.INVISIBLE);


                FlashCard tenCard = new FlashCard();
                card = tenCard.card;
                TextView dividend = (TextView)findViewById(R.id.dividendTxt);
//                dividend.setText("hello world");
                dividend.setText(Integer.toString(card[0][0]));
                Log.i("card00:",Integer.toString(card[0][0]));

                TextView divisor = (TextView) findViewById(R.id.divisorTxt);
                divisor.setText(Integer.toString(card[0][1]));
                bFlag = true;

            }
        });


        Button submit = (Button)findViewById(R.id.SubmitBtn);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(bFlag == false)
                    return;

                EditText ansET = (EditText)findViewById(R.id.AnswerTxt);
                String text = ansET.getText().toString();
                if(text.equals(""))
                    return;


                int ansInt = Integer.parseInt(text);
                ansET.setText("");

                CharSequence res = "";
                if(checkAnswer(card[quesNum][2],ansInt))
                {
                    rightNum++;
                    res = "right";

                }
                else
                {
                    res = "wrong";
                }

                //for toast:
                int duration = Toast.LENGTH_SHORT;
                Context context = getApplicationContext();
                Toast toast = Toast.makeText(context, res, duration);
                toast.show();


                quesNum++;

                if(quesNum==10)
                {
                    res();
                    bFlag = false;
                }
                else{
                    setNew();
                }


            }
        });

    }
    private void setNew(){

        if(quesNum>=10)
            return;
        TextView dividend = (TextView)findViewById(R.id.dividendTxt);
        dividend.setText(Integer.toString(card[quesNum][0]));
        TextView divisor = (TextView)findViewById(R.id.divisorTxt);
        divisor.setText(Integer.toString(card[quesNum][1]));
    }
    private void res()
    {
        RelativeLayout resL = (RelativeLayout) findViewById(R.id.RstLayout);
        TextView cor = (TextView) findViewById(R.id.RstCorrect);
        cor.setText(Integer.toString(rightNum));
        TextView wrong = (TextView)findViewById(R.id.RstWrong);
        wrong.setText(Integer.toString(10-rightNum));
        resL.setVisibility(View.VISIBLE);

        Context context = getApplicationContext();
        CharSequence result = "correct: "+ Integer.toString(rightNum);
        Toast.makeText(context, result, Toast.LENGTH_LONG).show();


    }
    private boolean checkAnswer(int num3, int ans)
    {
        if(num3 == ans)
            return true;
        else
            return false;
    }
}
