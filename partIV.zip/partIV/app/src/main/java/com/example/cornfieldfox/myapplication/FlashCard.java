package com.example.cornfieldfox.myapplication;

/**
 * Created by Cornfieldfox on 9/14/17.
 */
import java.util.Random;
public class FlashCard {
    public int[][] card;

    FlashCard()
    {
        this.card = tenCard();
    }

    public int[][] tenCard()
    {
         int[][] card = new int[10][3];
        Random r = new Random();
        for(int i = 0; i <10; i++)
        {
            int temp = r.nextInt() % 100;
            while(temp <= 10 ||isPrimary(temp))
            {
                temp = r.nextInt()%100;
            }
            System.out.println("temp::"+temp);

            int ds = divisor(temp);
            card[i][0] = temp;
            card[i][1] = ds;
            card[i][2] = temp/ds;

        }

        return card;
    }
    private int divisor(int num)
    {
        Random r = new Random();
        int res = r.nextInt()%num;
        while(res<=2)
            res = r.nextInt()%num;
        while(num % res!=0)
        {
            res--;
        }

        return res;
    }
    private boolean isPrimary(int num)
    {
        for(int i = 2; i<num/2; i++)
        {
            if(num % i == 0)
                return false;
        }
        return true;
    }


}
